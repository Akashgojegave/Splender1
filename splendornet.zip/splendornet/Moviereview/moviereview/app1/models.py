from django.db import models

# Create your models here.
class Movie_model(models.Model):
    id=models.IntegerField(primary_key=True)
    movieTitle=models.CharField(max_length=100)
    reviewContent=models.CharField(max_length=500,null=False)
    rating=models.IntegerField(null=False)
    createdAt=models.DateField()
    reviewer_email_id=models.EmailField(unique=True)
    status=models.CharField(max_length=100)
    genres=models.CharField(max_length=100)

    

