from django.contrib import admin
from django.urls import path,include

from .views import movie_view,movie_read,movie_delete,movie_update

# from .app1 import views

urlpatterns = [

    path("mcv/",movie_view , name="create_url"),
    path("mrv/",movie_read, name="read_url"),
    path("muv/<int:pk>/",movie_update, name="update_url"),
    path("mdv/<int:pk>/",movie_delete, name="delete_url"),
    # path("msv/<char:pk>/",movie_search, name="search_url")









]